export const AppRoutes = [
  { path: '**', redirectTo: 'home'}
];
